<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ATV BANDAS</title>
</head>

<body>
  <form method="post">
    <label for="BandsNames">
      <select name="bands" id="selector">
        <option value="blank">---</option>
        <option value="Rock">Foo Fighters</option>
        <option value="Soul">Blue Brothers</option>
        <option value="Pop">Coldplay</option>
        <option value="Blues">The Black Keys</option>
      </select>
    </label>
    <input type="submit" value="Enviar">
  </form>
</body>

</html>
<?php include './phpiers.php'?>